const colors = {
  primary: 'rgb(40,30,78)',
  text: 'rgb(51,39,88)',
  white: '#FFF',
  border: '#CCCCCC'
}

export default colors
